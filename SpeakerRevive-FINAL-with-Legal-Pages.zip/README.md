
# SpeakerRevive.com - Next.js 15 Full Source

This is production-ready Next.js 15 source for SpeakerRevive.com - mobile speaker cleaner tool.

## Features vs Competitors
- Real Web Audio API (no MP3), square wave for water, sine sweep for dust
- Frequency selector: 165Hz, 1kHz, 10kHz, 20kHz, 50kHz + custom slider (covers all your PAA: speaker cleaner sound 50000 hz etc)
- Modes: Loudspeaker / Ear Speaker / Both
- Sound / Vibrate / Both modes with navigator.vibrate
- Visualizer + progress, 60s water / 40s dust
- SEO silo: /ear-speaker-cleaner and /water-eject pages ready (add more for 10kHz, 20kHz etc)
- AEO ready: What is + How to blocks, FAQ
- 100% client-side, privacy first, no data collection - EEAT compliant 2026

## Deploy to Vercel + Cloudflare
1. Buy SpeakerRevive.com on Cloudflare Registrar
2. Push this folder to GitHub: speaker-revive repo
3. Vercel -> New Project -> Import GitHub repo
4. Add custom domain speakerrevive.com -> Vercel gives DNS: A 76.76.21.21 or CNAME cname.vercel-dns.com
5. Cloudflare DNS -> Add record. SSL Full (Strict), HTTP/3 ON, Brotli ON
6. Deploy - Done.

## Local Dev
npm install
npm run dev -> http://localhost:3000

## Next Steps SEO
- Create pages for /165hz /10000hz /20000hz /50000hz (copy ear-speaker-cleaner folder)
- Add blog posts: how to clean phone speaker, fix muffled sound
- Add Web App Manifest for PWA

Built for 2026 Google Policy: No scaled content, real utility, Core Web Vitals 100.
