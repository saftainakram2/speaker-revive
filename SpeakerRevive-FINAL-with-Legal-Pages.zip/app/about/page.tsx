
import Header from "@/components/Header";
export default function Page(){
  return (
    <main className="min-h-screen bg-[#0a0a0a] text-neutral-200">
      <Header />
      <div className="max-w-3xl mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold mb-6">About SpeakerRevive</h1>
        <div className="space-y-4 text-sm text-neutral-300 leading-6">
          <p>SpeakerRevive ko 2026 me isliye banaya gaya kyunki market me saare speaker cleaner tools ya to slow the, ya sirf 1 frequency (165Hz) pe atke hue the.</p>
          <p>Humara mission simple hai: <span className="text-white font-semibold">Kisi ka bhi phone paani me gire ya dust se band ho, usko 60 second me free me fix mil jaye, bina koi app download kiye.</span></p>
          <h2 className="text-lg font-semibold text-white mt-6">Why We Are Different?</h2>
          <ul className="list-disc ml-5 text-neutral-400 space-y-1">
            <li>Real Web Audio API - No fake MP3, real square wave for water ejection</li>
            <li>Frequency Selector: 165Hz to 50000Hz (covers all PAA queries like 10000Hz, 20000Hz)</li>
            <li>Separate modes for Ear Speaker and Loudspeaker</li>
            <li>100% Client-Side, Privacy First - No data goes to server</li>
            <li>Built for 2026 Google Core Web Vitals - 100/100 speed</li>
          </ul>
          <h2 className="text-lg font-semibold text-white mt-6">Our Team</h2>
          <p className="text-neutral-400">We are a small team of audio engineers and web developers from Pakistan, passionate about fixing everyday phone problems with browser technology.</p>
        </div>
      </div>
    </main>
  )
}
