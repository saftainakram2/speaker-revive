
import Header from "@/components/Header";
export default function Page(){
  return (
    <main className="min-h-screen bg-[#0a0a0a] text-neutral-200">
      <Header />
      <div className="max-w-3xl mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold mb-6">Contact Us</h1>
        <p className="text-sm text-neutral-400 mb-6">Koi sawal, suggestion, ya bug report? Hum 24h me reply karte hain.</p>
        
        <div className="bg-[#171717] border border-neutral-800 rounded-2xl p-6 space-y-4">
          <div>
            <div className="text-xs text-neutral-500">Email</div>
            <div className="text-sm font-medium">contact@speakerrevive.com</div>
          </div>
          <div>
            <div className="text-xs text-neutral-500">Support</div>
            <div className="text-sm font-medium">support@speakerrevive.com</div>
          </div>
          <div className="pt-4 text-xs text-neutral-500">
            Note: Ye tool 100% free hai. Hum koi paid support nahi bechte. Agar kisi ne aapse SpeakerRevive ke naam pe paise mange, to wo scam hai.
          </div>
        </div>

        <div className="mt-8 bg-[#171717] border border-neutral-800 rounded-2xl p-6">
          <h3 className="font-semibold mb-3">Send Message (No backend - mailto)</h3>
          <p className="text-xs text-neutral-400 mb-3">Ye form aapke default email app ko open karega.</p>
          <a href="mailto:contact@speakerrevive.com?subject=SpeakerRevive%20Feedback" className="inline-block bg-violet-600 px-5 py-2 rounded-full text-sm">Open Email App</a>
        </div>
      </div>
    </main>
  )
}
