
import Header from "@/components/Header";
export default function Page(){
  return (
    <main className="min-h-screen bg-[#0a0a0a] text-neutral-200">
      <Header />
      <div className="max-w-3xl mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold mb-6">Disclaimer</h1>
        <div className="space-y-4 text-sm text-neutral-400 leading-6">
          <p>SpeakerRevive ek browser-based sound cleaning tool hai. Ye Apple Watch ke water eject feature jaisa kaam karta hai - sound vibration se paani bahar nikalta hai.</p>
          <p><strong className="text-white">Important:</strong> Agar aapka phone salt water, samundar ke paani me gira hai, to turant tool use karke baad me professional cleaning karwao. Salt corrosion kar sakta hai.</p>
          <p>Humne is tool ko safe frequencies (100Hz-50000Hz) pe test kiya hai jo normal speakers ki range me hain. Phir bhi apne risk pe use karo. Hum kisi speaker damage ke liye liable nahi.</p>
          <p>Ye tool medical, industrial ya heavy water damage ke liye nahi hai. Sirf light moisture aur dust ke liye.</p>
        </div>
      </div>
    </main>
  )
}
