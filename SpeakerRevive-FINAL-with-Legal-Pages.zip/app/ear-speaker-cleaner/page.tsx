
import SpeakerCleaner from "@/components/SpeakerCleaner";
import Header from "@/components/Header";
export default function Page(){
  return (<main><Header /><div className="max-w-6xl mx-auto px-4 py-8"><h1 className="text-3xl font-bold mb-2">Ear Speaker Cleaner - Fix Muffled Calls</h1><p className="text-neutral-400 mb-6">Targeted cleaning for earpiece speaker that causes muffled phone calls. Uses gentle 800Hz-2kHz sweep.</p><SpeakerCleaner /></div></main>)
}
