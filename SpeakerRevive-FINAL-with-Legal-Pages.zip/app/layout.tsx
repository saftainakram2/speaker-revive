
import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "SpeakerRevive - Fix My Speaker | Eject Water & Dust (Free)",
  description: "Free phone speaker cleaner online tool to remove water, dust & muffled sound. Uses 165Hz sound vibration frequency to clean phone speaker safely. No app needed.",
  keywords: ["mobile speaker cleaner","fix my speaker","speaker cleaner","water eject","dust cleaner","165hz","ear speaker cleaner"],
  openGraph: {
    title: "SpeakerRevive - Fix My Speaker Instantly",
    description: "Eject water & dust from phone speakers in 60 seconds. 100% free, no app.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
