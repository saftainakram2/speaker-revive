
import Header from "@/components/Header";
import SpeakerCleaner from "@/components/SpeakerCleaner";

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <section id="tool" className="max-w-6xl mx-auto px-4 py-10">
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight">Fix My Speaker - Eject Water & Dust in Seconds</h1>
          <p className="text-neutral-400 mt-3 max-w-2xl mx-auto">Free online speaker cleaner uses 165Hz sound waves + vibration to restore crystal-clear audio. No app needed. Works on iPhone, Android, tablets.</p>
        </div>
        <SpeakerCleaner />
      </section>

      <section id="how" className="max-w-6xl mx-auto px-4 py-12 grid md:grid-cols-3 gap-6">
        <div className="bg-[#171717] border border-neutral-800 p-6 rounded-2xl">
          <h3 className="font-semibold mb-2">What is SpeakerRevive?</h3>
          <p className="text-sm text-neutral-400">SpeakerRevive is a browser-based speaker cleaner that uses controlled sound waves and vibration to eject water and remove dust from phone speakers safely. It uses 165Hz low frequency for water and sweep 1kHz-15kHz for dust, no app install.</p>
        </div>
        <div className="bg-[#171717] border border-neutral-800 p-6 rounded-2xl">
          <h3 className="font-semibold mb-2">How to Use in 3 Steps</h3>
          <ol className="text-sm text-neutral-400 list-decimal ml-4 space-y-1">
            <li>Set volume to MAX, remove case, place speaker down.</li>
            <li>Choose Eject Water or Remove Dust, tap Play.</li>
            <li>Wait 60s till 100%, test with music, repeat if needed.</li>
          </ol>
        </div>
        <div className="bg-[#171717] border border-neutral-800 p-6 rounded-2xl">
          <h3 className="font-semibold mb-2">Why Low Frequency Works</h3>
          <p className="text-sm text-neutral-400">Water ejection needs large diaphragm displacement, which happens at low frequencies like 165Hz. High frequencies move fast but small, good for dust. Our square wave creates max pressure.</p>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 py-8">
        <h2 className="text-2xl font-bold mb-4">Fix My Speaker vs Traditional Methods</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm border border-neutral-800 rounded-xl overflow-hidden">
            <thead className="bg-neutral-900"><tr><th className="p-3 text-left">Method</th><th className="p-3">Time</th><th className="p-3">Effectiveness</th><th className="p-3">Risk</th></tr></thead>
            <tbody>
              <tr className="border-t border-neutral-800"><td className="p-3 font-semibold text-violet-400">SpeakerRevive</td><td className="p-3">60 sec</td><td className="p-3">98%</td><td className="p-3">None</td></tr>
              <tr className="border-t border-neutral-800"><td className="p-3">Rice Method</td><td className="p-3">24-48h</td><td className="p-3">30%</td><td className="p-3">Dust residue</td></tr>
              <tr className="border-t border-neutral-800"><td className="p-3">Hair Dryer</td><td className="p-3">10 min</td><td className="p-3">Low</td><td className="p-3">Heat damage</td></tr>
            </tbody>
          </table>
        </div>
      </section>

      <section id="faq" className="max-w-3xl mx-auto px-4 py-12">
        <h2 className="text-2xl font-bold mb-4">FAQs</h2>
        <div className="space-y-3">
          <div className="bg-[#171717] border border-neutral-800 p-4 rounded-xl"><div className="font-semibold">Is it safe?</div><div className="text-sm text-neutral-400">Yes, uses frequencies within normal speaker range, no damage. Non-contact cleaning.</div></div>
          <div className="bg-[#171717] border border-neutral-800 p-4 rounded-xl"><div className="font-semibold">Does it work on iPhone & Android?</div><div className="text-sm text-neutral-400">Yes, any device with browser and speaker - iPhone, Samsung, Pixel, Xiaomi, tablets.</div></div>
          <div className="bg-[#171717] border border-neutral-800 p-4 rounded-xl"><div className="font-semibold">How often should I use?</div><div className="text-sm text-neutral-400">After water exposure immediately, for dust weekly as maintenance.</div></div>
        </div>
      </section>

      <footer className="border-t border-neutral-800 py-8 text-center text-xs text-neutral-500">
        <div className="flex justify-center gap-4 mb-3">
          <a href="/about" className="hover:text-white">About</a>
          <a href="/contact" className="hover:text-white">Contact</a>
          <a href="/privacy-policy" className="hover:text-white">Privacy Policy</a>
          <a href="/terms" className="hover:text-white">Terms</a>
          <a href="/disclaimer" className="hover:text-white">Disclaimer</a>
        </div>
        © 2026 SpeakerRevive.com - Built with Web Audio API, 100% Client-Side, Privacy First. No data collected.
      </footer>
    </main>
  );
}
