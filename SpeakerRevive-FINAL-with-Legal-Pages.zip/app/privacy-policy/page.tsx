
import Header from "@/components/Header";
export default function Page(){
  return (
    <main className="min-h-screen bg-[#0a0a0a] text-neutral-200">
      <Header />
      <div className="max-w-3xl mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold mb-6">Privacy Policy - SpeakerRevive</h1>
        <p className="text-sm text-neutral-400 mb-4">Last Updated: January 2026</p>
        
        <div className="space-y-6 text-sm leading-6">
          <section>
            <h2 className="text-lg font-semibold text-white mb-2">1. 100% Client-Side Processing</h2>
            <p className="text-neutral-400">SpeakerRevive.com ka tool 100% aapke browser me chalta hai. Hum Web Audio API se sound generate karte hain. Aapki koi audio, koi data, koi file hamare server pe upload nahi hoti. Iska matlab aapki privacy 100% safe hai.</p>
          </section>
          <section>
            <h2 className="text-lg font-semibold text-white mb-2">2. No Data Collection</h2>
            <p className="text-neutral-400">Hum aapka naam, email, phone number, ya speaker ka data collect nahi karte. Tool use karne ke liye signup ki zarurat nahi.</p>
          </section>
          <section>
            <h2 className="text-lg font-semibold text-white mb-2">3. Cookies & Analytics</h2>
            <p className="text-neutral-400">Hum sirf Cloudflare Web Analytics aur Vercel Analytics use karte hain jo anonymous page views count karte hain (privacy-friendly, no cookies). Koi personal tracking nahi.</p>
          </section>
          <section>
            <h2 className="text-lg font-semibold text-white mb-2">4. Third-Party</h2>
            <p className="text-neutral-400">Hum Google AdSense (future me) use kar sakte hain jo cookies use karta hai ads dikhane ke liye. Aap apne browser se cookies disable kar sakte hain.</p>
          </section>
          <section>
            <h2 className="text-lg font-semibold text-white mb-2">5. Contact</h2>
            <p className="text-neutral-400">Privacy se related koi sawal ho to contact@speakerrevive.com pe email karen.</p>
          </section>
        </div>
      </div>
    </main>
  )
}
