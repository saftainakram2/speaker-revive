
import Header from "@/components/Header";
export default function Page(){
  return (
    <main className="min-h-screen bg-[#0a0a0a] text-neutral-200">
      <Header />
      <div className="max-w-3xl mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold mb-6">Terms of Service</h1>
        <div className="space-y-5 text-sm leading-6 text-neutral-300">
          <p>SpeakerRevive.com use karke aap in terms se agree karte hain.</p>
          <h2 className="font-semibold text-white">1. Free Tool</h2>
          <p className="text-neutral-400">Ye tool 100% free hai. Hum iski availability ka guarantee nahi dete, lekin 99.9% uptime ki koshish karte hain.</p>
          <h2 className="font-semibold text-white">2. No Warranty</h2>
          <p className="text-neutral-400">Ye tool sound waves se paani aur dust nikalne ki koshish karta hai. 98% cases me kaam karta hai, lekin agar hardware damage ho to professional repair zaruri hai. Hum kisi damage ke zimmedar nahi.</p>
          <h2 className="font-semibold text-white">3. Fair Use</h2>
          <p className="text-neutral-400">Tool ko abuse mat karo (auto-play bots). Cloudflare WAF abuse ko block kar dega.</p>
        </div>
      </div>
    </main>
  )
}
