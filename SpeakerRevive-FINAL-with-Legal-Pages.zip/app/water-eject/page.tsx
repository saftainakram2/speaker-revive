
import SpeakerCleaner from "@/components/SpeakerCleaner";
import Header from "@/components/Header";
export default function Page(){
  return (<main><Header /><div className="max-w-6xl mx-auto px-4 py-8"><h1 className="text-3xl font-bold mb-2">Water Eject Tool - Remove Water from Phone Speaker</h1><p className="text-neutral-400 mb-6">Eject water using 165Hz square wave vibration. Works like Apple Watch water eject but for any phone.</p><SpeakerCleaner /></div></main>)
}
