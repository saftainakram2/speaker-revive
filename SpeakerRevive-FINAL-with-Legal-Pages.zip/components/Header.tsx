
export default function Header() {
  return (
    <header className="border-b border-neutral-800 sticky top-0 z-50 bg-[#0a0a0a]/80 backdrop-blur">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2 font-bold text-xl">
          <span className="w-8 h-8 bg-violet-600 rounded-lg flex items-center justify-center">🔊</span>
          SpeakerRevive
        </div>
        <nav className="hidden md:flex gap-6 text-sm text-neutral-400">
          <a href="#tool" className="hover:text-white">Clean Now</a>
          <a href="#how" className="hover:text-white">How it Works</a>
          <a href="#faq" className="hover:text-white">FAQ</a>
        </nav>
        <a href="#tool" className="bg-violet-600 px-4 py-2 rounded-full text-sm font-medium">Clean Now</a>
      </div>
    </header>
  );
}
