"use client";
import { useRef, useState, useEffect } from "react";

type Mode = "loud" | "ear" | "both";
type CleanType = "water" | "dust";
type SoundMode = "sound" | "vibrate" | "both";

export default function SpeakerCleaner() {
  const [mode, setMode] = useState<Mode>("both");
  const [cleanType, setCleanType] = useState<CleanType>("water");
  const [soundMode, setSoundMode] = useState<SoundMode>("both");
  const [freq, setFreq] = useState(165);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscRef = useRef<OscillatorNode | null>(null);
  const gainRef = useRef<GainNode | null>(null);
  const intervalRef = useRef<any>(null);
  const vibIntervalRef = useRef<any>(null);

  const totalDuration = cleanType === "water" ? 60 : 40; // seconds

  useEffect(() => {
    return () => stopAll();
  }, []);

  const stopAll = () => {
    if (oscRef.current) {
      try { oscRef.current.stop(); } catch {}
      oscRef.current = null;
    }
    if (audioCtxRef.current) {
      // keep context for reuse but close oscillator
    }
    if (intervalRef.current) clearInterval(intervalRef.current);
    if (vibIntervalRef.current) clearInterval(vibIntervalRef.current);
    if (navigator.vibrate) navigator.vibrate(0);
  };

  const start = async () => {
    if (isPlaying) {
      pause();
      return;
    }
    // init audio
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    const ctx = audioCtxRef.current;
    if (ctx.state === "suspended") await ctx.resume();

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = cleanType === "water" ? "square" : "sine";
    osc.frequency.value = freq;
    gain.gain.value = 0.9;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    oscRef.current = osc;
    gainRef.current = gain;

    // dust mode sweep
    if (cleanType === "dust") {
      let direction = 1;
      const sweep = setInterval(() => {
        if (!oscRef.current) { clearInterval(sweep); return; }
        const current = oscRef.current.frequency.value;
        let next = current + direction * 80;
        if (next > freq + 800 || next < freq - 400) direction *= -1;
        oscRef.current.frequency.value = next;
      }, 200);
      intervalRef.current = sweep as any; // reuse for now, will override below
      // we need separate for progress, so keep sweep ref separately? simplify: use two intervals
    }

    setIsPlaying(true);
    // progress
    let elapsed = (progress / 100) * totalDuration;
    const progInterval = setInterval(() => {
      elapsed += 0.1;
      const p = Math.min(100, (elapsed / totalDuration) * 100);
      setProgress(p);
      if (p >= 100) {
        clearInterval(progInterval);
        stopAll();
        setIsPlaying(false);
        setProgress(100);
      }
    }, 100);
    intervalRef.current = progInterval;

    // vibration
    if (soundMode !== "sound" && navigator.vibrate) {
      const vibPattern = () => {
        navigator.vibrate([200, 100, 200]);
      };
      vibPattern();
      vibIntervalRef.current = setInterval(vibPattern, 800);
    }
  };

  const pause = () => {
    stopAll();
    setIsPlaying(false);
  };

  const reset = () => {
    stopAll();
    setIsPlaying(false);
    setProgress(0);
  };

  return (
    <div className="max-w-3xl mx-auto w-full">
      <div className="bg-[#171717] border border-neutral-800 rounded-[24px] p-6 md:p-8 shadow-2xl">
        {/* Mode Selector */}
        <div className="flex gap-2 mb-6">
          {[
            { id: "loud", label: "Loudspeaker" },
            { id: "ear", label: "Ear Speaker" },
            { id: "both", label: "Both" },
          ].map((m) => (
            <button
              key={m.id}
              onClick={() => setMode(m.id as Mode)}
              className={`flex-1 py-2 rounded-full text-sm border ${mode === m.id ? "bg-violet-600 border-violet-600 text-white" : "border-neutral-700 text-neutral-400"}`}
            >
              {m.label}
            </button>
          ))}
        </div>

        {/* Clean Type */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <button onClick={() => { setCleanType("water"); setFreq(165); reset(); }} className={`p-4 rounded-xl border text-left ${cleanType==="water" ? "bg-violet-600/20 border-violet-600" : "border-neutral-800"}`}>
            <div className="text-2xl">💧</div>
            <div className="font-semibold mt-1">Eject Water</div>
            <div className="text-xs text-neutral-400">Removes moisture in 60s</div>
          </button>
          <button onClick={() => { setCleanType("dust"); setFreq(1000); reset(); }} className={`p-4 rounded-xl border text-left ${cleanType==="dust" ? "bg-violet-600/20 border-violet-600" : "border-neutral-800"}`}>
            <div className="text-2xl">🌪️</div>
            <div className="font-semibold mt-1">Remove Dust</div>
            <div className="text-xs text-neutral-400">Clears lint & debris</div>
          </button>
        </div>

        {/* Frequency */}
        <div className="mb-6">
          <div className="text-xs text-neutral-400 mb-2">Frequency - {cleanType==="water" ? "Low frequency moves water better" : "Sweep for dust removal"}</div>
          <div className="flex flex-wrap gap-2 mb-3">
            {[165, 1000, 10000, 20000, 50000].map(f => (
              <button key={f} onClick={()=>{ setFreq(f); if(isPlaying){ if(oscRef.current) oscRef.current.frequency.value = f; }}} className={`px-3 py-1 rounded-full text-xs border ${freq===f ? "bg-white text-black border-white" : "border-neutral-700 text-neutral-300"}`}>{f}Hz</button>
            ))}
          </div>
          <input type="range" min={100} max={50000} value={freq} onChange={e=>{ const v=parseInt(e.target.value); setFreq(v); if(oscRef.current) oscRef.current.frequency.value=v; }} className="w-full accent-violet-600" />
          <div className="text-center text-3xl font-bold mt-2">{freq}Hz</div>
        </div>

        {/* Sound Mode */}
        <div className="flex gap-2 mb-6 justify-center">
          {(["sound","vibrate","both"] as SoundMode[]).map(s=>(
            <button key={s} onClick={()=>setSoundMode(s)} className={`px-4 py-1.5 rounded-full text-xs border ${soundMode===s ? "bg-neutral-100 text-black" : "border-neutral-700 text-neutral-400"}`}>{s.toUpperCase()}</button>
          ))}
        </div>

        {/* Play Button + Visualizer */}
        <div className="flex flex-col items-center gap-4">
          <button onClick={start} className={`w-28 h-28 rounded-full flex items-center justify-center text-4xl shadow-[0_0_40px_rgba(139,92,246,0.5)] transition ${isPlaying ? "bg-red-500" : "bg-violet-600 hover:scale-105"}`}>
            {isPlaying ? "⏸️" : "▶️"}
          </button>

          {isPlaying && (
            <div className="flex gap-1 h-10 items-end">
              {[0,1,2,3,4].map(i=><div key={i} className="w-1.5 bg-violet-500 rounded-full visualizer-bar" style={{animationDelay:`${i*0.1}s`}}></div>)}
            </div>
          )}

          <div className="w-full bg-neutral-800 rounded-full h-2 overflow-hidden">
            <div className="bg-violet-600 h-full transition-all" style={{width:`${progress}%`}}></div>
          </div>
          <div className="text-xs text-neutral-400">{isPlaying ? `Cleaning ${mode}... ${Math.round(progress)}%` : progress===100 ? "✅ Done! Test with music" : "Tap to Clean - Keep volume MAX, speaker facing down"} </div>

          {progress===100 && (
            <div className="flex gap-2">
              <button onClick={reset} className="px-4 py-2 rounded-full bg-white text-black text-sm">Repeat</button>
              <button onClick={()=>setProgress(0)} className="px-4 py-2 rounded-full border border-neutral-700 text-sm">Test Sound</button>
            </div>
          )}
        </div>

        <div className="mt-6 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-xl text-xs text-yellow-200">
          ⚠️ Set volume to MAX • Remove phone case • Place speaker facing down on flat surface • Disconnect Bluetooth
        </div>
      </div>
    </div>
  );
}
